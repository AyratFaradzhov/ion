import { Mail, MessageCircle, Phone, Send } from "lucide-react";
import { useState } from "react";

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    budget: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    alert("Спасибо за ваше сообщение! Мы ответим в течение 1-2 рабочих дней.");
    setFormData({ name: "", email: "", company: "", budget: "", message: "" });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="bg-[#fafafa]">
      {/* Hero Section - Light with gradient */}
      <section className="pt-40 pb-24 bg-white relative overflow-hidden">
        <div className="absolute top-20 right-20 w-[500px] h-[500px] bg-gradient-to-br from-[#8b5cf6]/20 to-[#06b6d4]/20 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-gradient-to-tl from-[#06b6d4]/15 to-[#a78bfa]/15 rounded-full blur-3xl" />
        
        <div className="mx-auto w-full max-w-[1440px] px-12 relative z-10">
          <div className="grid grid-cols-12 gap-12">
            <div className="col-span-8">
              <h1 className="text-7xl font-bold text-[#0a0a0a] leading-tight mb-8">
                Свяжитесь <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">с нами</span>
              </h1>
              <p className="text-2xl text-[#6b7280] leading-relaxed font-light">
                Расскажите о вашей задаче, и мы честно оценим, подходим ли мы для её решения.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-24 bg-[#fafafa]">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="grid grid-cols-12 gap-8 mb-16">
            <div className="col-span-4 group">
              <div className="rounded-3xl bg-white border border-black/[0.06] p-10 h-full shadow-sm hover:shadow-xl transition-all">
                <div className="mb-8">
                  <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] shadow-lg shadow-purple-500/25">
                    <Mail className="w-7 h-7 text-white" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-[#0a0a0a] mb-3">Напишите нам</h3>
                <p className="text-base text-[#6b7280] mb-6">hello@prism.studio</p>
                <a href="mailto:hello@prism.studio" className="inline-flex items-center gap-2 text-sm font-semibold text-[#8b5cf6] hover:gap-3 transition-all">
                  Отправить письмо →
                </a>
              </div>
            </div>

            <div className="col-span-4 group">
              <div className="rounded-3xl bg-white border border-black/[0.06] p-10 h-full shadow-sm hover:shadow-xl transition-all">
                <div className="mb-8">
                  <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#06b6d4] to-[#8b5cf6] shadow-lg shadow-cyan-500/25">
                    <Phone className="w-7 h-7 text-white" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-[#0a0a0a] mb-3">Назначить звонок</h3>
                <p className="text-base text-[#6b7280] mb-6">30-минутная вводная встреча</p>
                <a href="#" className="inline-flex items-center gap-2 text-sm font-semibold text-[#8b5cf6] hover:gap-3 transition-all">
                  Смотреть календарь →
                </a>
              </div>
            </div>

            <div className="col-span-4 group">
              <div className="rounded-3xl bg-white border border-black/[0.06] p-10 h-full shadow-sm hover:shadow-xl transition-all">
                <div className="mb-8">
                  <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#a78bfa] to-[#06b6d4] shadow-lg shadow-purple-500/25">
                    <MessageCircle className="w-7 h-7 text-white" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-[#0a0a0a] mb-3">Живой чат</h3>
                <p className="text-base text-[#6b7280] mb-6">Пн-Пт, 9:00-18:00 EST</p>
                <a href="#" className="inline-flex items-center gap-2 text-sm font-semibold text-[#8b5cf6] hover:gap-3 transition-all">
                  Начать чат →
                </a>
              </div>
            </div>
          </div>

          {/* Form & Info */}
          <div className="grid grid-cols-12 gap-8">
            {/* Form */}
            <div className="col-span-7">
              <div className="rounded-3xl bg-white border border-black/[0.06] p-12 shadow-sm">
                <h2 className="text-4xl font-bold text-[#0a0a0a] mb-3">Отправьте сообщение</h2>
                <p className="text-base text-[#6b7280] mb-10 leading-relaxed">
                  Расскажите о задаче, и мы ответим в течение 1-2 рабочих дней.
                </p>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-semibold text-[#0a0a0a] mb-3">
                        Имя
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full rounded-2xl border border-black/[0.08] bg-[#fafafa] px-5 py-4 text-base text-[#0a0a0a] placeholder:text-[#9ca3af] focus:border-[#8b5cf6] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all"
                        placeholder="Иван Иванов"
                      />
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-sm font-semibold text-[#0a0a0a] mb-3">
                        Email
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full rounded-2xl border border-black/[0.08] bg-[#fafafa] px-5 py-4 text-base text-[#0a0a0a] placeholder:text-[#9ca3af] focus:border-[#8b5cf6] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all"
                        placeholder="ivan@company.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="company" className="block text-sm font-semibold text-[#0a0a0a] mb-3">
                      Компания
                    </label>
                    <input
                      type="text"
                      id="company"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      className="w-full rounded-2xl border border-black/[0.08] bg-[#fafafa] px-5 py-4 text-base text-[#0a0a0a] placeholder:text-[#9ca3af] focus:border-[#8b5cf6] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all"
                      placeholder="Ваша компания"
                    />
                  </div>

                  <div>
                    <label htmlFor="budget" className="block text-sm font-semibold text-[#0a0a0a] mb-3">
                      Бюджет проекта
                    </label>
                    <select
                      id="budget"
                      name="budget"
                      value={formData.budget}
                      onChange={handleChange}
                      className="w-full rounded-2xl border border-black/[0.08] bg-[#fafafa] px-5 py-4 text-base text-[#0a0a0a] focus:border-[#8b5cf6] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all"
                    >
                      <option value="">Выберите диапазон</option>
                      <option value="<50k">Менее $50k</option>
                      <option value="50k-100k">$50k - $100k</option>
                      <option value="100k-250k">$100k - $250k</option>
                      <option value=">250k">Более $250k</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-semibold text-[#0a0a0a] mb-3">
                      Детали проекта
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={6}
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full rounded-2xl border border-black/[0.08] bg-[#fafafa] px-5 py-4 text-base text-[#0a0a0a] placeholder:text-[#9ca3af] focus:border-[#8b5cf6] focus:outline-none focus:ring-2 focus:ring-[#8b5cf6]/20 transition-all resize-none"
                      placeholder="Расскажите о вашем проекте, целях, таймлайне..."
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full inline-flex items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] px-8 py-5 text-lg font-bold text-white shadow-lg shadow-purple-500/30 transition-all hover:shadow-xl hover:shadow-purple-500/40 hover:scale-105"
                  >
                    Отправить сообщение
                    <Send className="h-5 w-5" />
                  </button>
                </form>
              </div>
            </div>

            {/* Info Sidebar */}
            <div className="col-span-5 space-y-8">
              {/* What to Expect */}
              <div className="rounded-3xl bg-white border border-black/[0.06] p-10 shadow-sm">
                <h3 className="text-2xl font-bold text-[#0a0a0a] mb-8">Как будем работать</h3>
                <div className="space-y-8">
                  {[
                    {
                      step: "1",
                      title: "Ответ в течение 1-2 дней",
                      description: "Изучим ваше сообщение и ответим, подходим ли мы для задачи.",
                    },
                    {
                      step: "2",
                      title: "Обсуждение проекта",
                      description: "Разберёмся в требованиях, целях, ограничениях и контексте.",
                    },
                    {
                      step: "3",
                      title: "Оценка и предложение",
                      description: "Подготовим честную оценку сроков, стоимости и scope работ.",
                    },
                    {
                      step: "4",
                      title: "Старт работы",
                      description: "Если всё подходит — начинаем с погружения и проектирования.",
                    },
                  ].map((item, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] text-base font-bold text-white">
                        {item.step}
                      </div>
                      <div>
                        <div className="text-base font-bold text-[#0a0a0a] mb-2">{item.title}</div>
                        <div className="text-sm text-[#6b7280] leading-relaxed">{item.description}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Location */}
              <div className="rounded-3xl bg-gradient-to-br from-[#8b5cf6]/5 to-[#06b6d4]/5 border border-[#8b5cf6]/20 p-10">
                <div className="mb-6">
                  <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] shadow-lg shadow-purple-500/25">
                    <div className="h-3 w-3 rounded-full bg-white" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-[#0a0a0a] mb-3">Офис</h3>
                <p className="text-base text-[#6b7280] leading-relaxed">
                  Сан-Франциско, США<br />
                  Remote-first, работаем глобально
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Section - Light */}
      <section className="py-40 bg-white">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="grid grid-cols-12 gap-12">
            <div className="col-span-8 col-start-3 text-center">
              <h2 className="text-5xl font-bold text-[#0a0a0a] mb-6 leading-tight">
                Работаем с <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">разными компаниями</span>
              </h2>
              <p className="text-xl text-[#6b7280] leading-relaxed max-w-2xl mx-auto">
                От стартапов до established бизнесов — главное, чтобы был фокус на качество и готовность работать вместе.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
