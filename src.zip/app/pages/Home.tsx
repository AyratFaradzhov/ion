import { Link } from "react-router";
import {
  ArrowRight,
  Sparkles,
  Zap,
  Target,
  ExternalLink,
} from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function Home() {
  return (
    <div className="bg-[#fafafa]">
      {/* Hero Section - Light with floating gradients */}
      <section className="relative min-h-screen flex items-center overflow-hidden bg-white">
        {/* Animated gradient blobs - prepared for animation */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 right-10 w-[600px] h-[600px] bg-gradient-to-br from-[#8b5cf6]/30 via-[#a78bfa]/20 to-[#06b6d4]/30 rounded-full blur-3xl opacity-60 animate-pulse" />
          <div className="absolute bottom-20 left-10 w-[500px] h-[500px] bg-gradient-to-tr from-[#06b6d4]/30 to-[#8b5cf6]/20 rounded-full blur-3xl opacity-50" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-gradient-to-r from-[#a78bfa]/20 to-[#06b6d4]/20 rounded-full blur-2xl opacity-40" />
        </div>

        <div className="mx-auto w-full max-w-[1440px] px-12 relative z-10 py-32">
          <div className="grid grid-cols-12 gap-12">
            {/* Left side - asymmetric layout */}
            <div className="col-span-7 space-y-12">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#8b5cf6]/10 to-[#06b6d4]/10 border border-[#8b5cf6]/20">
                <Sparkles className="w-4 h-4 text-[#8b5cf6]" />
                <span className="text-sm font-semibold bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                  Творческая продуктовая студия
                </span>
              </div>

              {/* Oversized Headline */}
              <h1 className="text-[7rem] font-bold leading-[0.95] tracking-tight text-[#0a0a0a]">
                Создаём
                <br />
                <span className="bg-gradient-to-r from-[#8b5cf6] via-[#a78bfa] to-[#06b6d4] bg-clip-text text-transparent">
                  продукты
                </span>
                <br />с душой
              </h1>

              {/* Supporting Text */}
              <p className="text-2xl text-[#6b7280] max-w-xl leading-relaxed font-light">
                Проектируем и разрабатываем цифровые продукты,
                где технологии встречаются с креативностью и
                вниманием к деталям.
              </p>

              {/* CTA Group */}
              <div className="flex items-center gap-4 pt-6">
                <Link
                  to="/contact"
                  className="group inline-flex items-center gap-3 rounded-2xl bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] px-8 py-5 text-lg font-bold text-white shadow-2xl shadow-purple-500/30 transition-all hover:shadow-purple-500/40 hover:scale-105"
                >
                  Начать проект
                  <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
                </Link>
                <Link
                  to="/work"
                  className="inline-flex items-center gap-2 rounded-2xl border border-[#0a0a0a] bg-white px-8 py-5 text-lg font-bold text-[#0a0a0a] transition-all hover:bg-[#0a0a0a] hover:text-white"
                >
                  Наш подход
                </Link>
              </div>
            </div>

            {/* Right side - visual element placeholder for animation */}
            <div className="col-span-5 flex items-center justify-center">
              <div className="relative w-full h-[500px]">
                {/* Floating card elements - prepared for animation */}
                <div className="absolute top-0 right-0 w-64 h-64 rounded-3xl bg-gradient-to-br from-[#8b5cf6] to-[#a78bfa] shadow-2xl shadow-purple-500/30 transform rotate-6 hover:rotate-12 transition-transform" />
                <div className="absolute bottom-10 left-10 w-72 h-48 rounded-3xl bg-white border border-black/[0.08] shadow-xl p-6 hover:scale-105 transition-transform">
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#06b6d4] to-[#8b5cf6]" />
                    <div className="h-4 w-3/4 bg-gradient-to-r from-[#e5e7eb] to-[#f3f4f6] rounded" />
                    <div className="h-4 w-1/2 bg-gradient-to-r from-[#e5e7eb] to-[#f3f4f6] rounded" />
                  </div>
                </div>
                <div className="absolute top-1/3 left-1/4 w-56 h-56 rounded-full bg-gradient-to-br from-[#06b6d4]/40 to-[#8b5cf6]/40 blur-2xl" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Principles Section - Light cards on light background */}
      <section className="py-32 bg-[#fafafa]">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="grid grid-cols-12 gap-8">
            {[
              {
                icon: Zap,
                title: "Структура",
                desc: "Системный подход к каждому проекту",
              },
              {
                icon: Sparkles,
                title: "Прозрачность",
                desc: "Открытая коммуникация на всех этапах",
              },
              {
                icon: Target,
                title: "Качество",
                desc: "Внимание к деталям и стандартам",
              },
              {
                icon: ArrowRight,
                title: "Партнёрство",
                desc: "Тесная работа с вашей командой",
              },
            ].map((item, index) => (
              <div key={index} className="col-span-3 group">
                <div className="rounded-3xl bg-white border border-black/[0.06] p-8 h-full shadow-sm hover:shadow-xl hover:scale-105 transition-all duration-300">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center mb-6 shadow-lg shadow-purple-500/20 group-hover:scale-110 transition-transform">
                    <item.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="font-bold text-[#0a0a0a] mb-3 text-[20px]">
                    {item.title}
                  </h3>
                  <p className="text-sm text-[#6b7280] leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How We Work - Dark section for contrast */}
      <section className="py-40 bg-gradient-to-b from-[#0a0a0a] to-[#141414] text-white relative overflow-hidden">
        {/* Gradient glow */}
        <div className="absolute top-0 left-1/4 w-[800px] h-[400px] bg-gradient-to-r from-[#8b5cf6]/20 to-[#06b6d4]/20 blur-3xl" />

        <div className="mx-auto w-full max-w-[1440px] px-12 relative z-10">
          {/* Asymmetric header */}
          <div className="grid grid-cols-12 gap-12 mb-24">
            <div className="col-span-5">
              <h2 className="text-6xl font-bold leading-tight">
                Как мы
                <br />
                <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                  работаем
                </span>
              </h2>
            </div>
            <div className="col-span-6 col-start-7 flex items-center">
              <p className="text-xl text-[#a1a1aa] leading-relaxed">
                Мы не гонимся за трендами и не идём на
                компромиссы. Каждое решение опирается на анализ,
                проверенные паттерны и понятные бизнес-цели.
              </p>
            </div>
          </div>

          {/* Dynamic grid */}
          <div className="grid grid-cols-12 gap-6">
            {/* Large card */}
            <div className="col-span-6 row-span-2">
              <div className="rounded-3xl bg-white/[0.03] border border-white/[0.1] p-12 h-full backdrop-blur-sm hover:bg-white/[0.05] transition-all">
                <div className="h-1 w-24 bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] rounded-full mb-8" />
                <h3 className="text-4xl font-bold text-white mb-6 leading-tight">
                  Продуманная
                  <br />
                  архитектура
                </h3>
                <p className="text-lg text-[#a1a1aa] leading-relaxed mb-8">
                  Начинаем с логики, структуры данных и
                  системного проектирования, а не с визуального
                  слоя.
                </p>
                <div className="space-y-4">
                  {[
                    "Модульная архитектура",
                    "Чистый код",
                    "Масштабируемость",
                  ].map((item, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-3"
                    >
                      <div className="w-2 h-2 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4]" />
                      <span className="text-sm text-[#a1a1aa]">
                        {item}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Smaller cards */}
            <div className="col-span-3">
              <div className="rounded-3xl bg-white/[0.03] border border-white/[0.1] p-8 h-full backdrop-blur-sm hover:bg-white/[0.05] transition-all">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#06b6d4] to-[#8b5cf6] flex items-center justify-center mb-6">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">
                  Чистая разработка
                </h3>
                <p className="text-sm text-[#a1a1aa] leading-relaxed">
                  Современный стек, стандарты кода и проверенные
                  паттерны.
                </p>
              </div>
            </div>

            <div className="col-span-3">
              <div className="rounded-3xl bg-white/[0.03] border border-white/[0.1] p-8 h-full backdrop-blur-sm hover:bg-white/[0.05] transition-all">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center mb-6">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">
                  Обоснованный UX
                </h3>
                <p className="text-sm text-[#a1a1aa] leading-relaxed">
                  Каждое решение имеет причину: логика,
                  сценарии, иерархия.
                </p>
              </div>
            </div>

            <div className="col-span-6">
              <div className="rounded-3xl bg-gradient-to-br from-[#8b5cf6]/10 to-[#06b6d4]/10 border border-[#8b5cf6]/20 p-8 backdrop-blur-sm">
                <h3 className="text-2xl font-bold text-white mb-4">
                  Измеримые цели
                </h3>
                <p className="text-base text-[#a1a1aa] leading-relaxed">
                  Привязываем решения к реальным задачам —
                  конверсии, удобству, производительности.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services - Light with gradient accents */}
      <section className="py-40 bg-white">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="text-center mb-20">
            <h2 className="text-6xl font-bold text-[#0a0a0a] mb-6 leading-tight">
              Направления{" "}
              <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                работы
              </span>
            </h2>
            <p className="text-xl text-[#6b7280] max-w-3xl mx-auto">
              Работаем над цифровыми продуктами, где важны
              технологическая экспертиза и стратегическое
              мышление.
            </p>
          </div>

          <div className="grid grid-cols-12 gap-8">
            {[
              {
                title: "Продуктовые сайты",
                desc: "Маркетинговые платформы для B2B и SaaS продуктов.",
                tags: ["Next.js", "CMS", "SEO"],
                color: "from-[#8b5cf6] to-[#a78bfa]",
              },
              {
                title: "Внутренние платформы",
                desc: "Инструменты для команд и операций.",
                tags: ["React", "TypeScript", "API"],
                color: "from-[#06b6d4] to-[#8b5cf6]",
              },
              {
                title: "UX/UI дизайн",
                desc: "Дизайн-системы и интерфейсы.",
                tags: [
                  "Design Systems",
                  "Prototyping",
                  "Testing",
                ],
                color: "from-[#8b5cf6] to-[#06b6d4]",
              },
            ].map((service, index) => (
              <div
                key={index}
                className={`group ${index < 2 ? "col-span-5" : "col-span-6 col-start-4"} ${index === 0 ? "col-start-2" : ""}`}
              >
                <div className="relative rounded-3xl bg-[#fafafa] border border-black/[0.06] p-10 h-full overflow-hidden hover:shadow-2xl hover:scale-105 transition-all duration-300">
                  {/* Gradient glow on hover */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-0 group-hover:opacity-5 transition-opacity`}
                  />

                  <div className="relative z-10">
                    <div
                      className={`inline-flex px-4 py-2 rounded-full bg-gradient-to-r ${service.color} mb-6`}
                    >
                      <span className="text-xs font-bold text-white">
                        0{index + 1}
                      </span>
                    </div>
                    <h3 className="text-3xl font-bold text-[#0a0a0a] mb-4">
                      {service.title}
                    </h3>
                    <p className="text-base text-[#6b7280] leading-relaxed mb-6">
                      {service.desc}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {service.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-3 py-1.5 rounded-full bg-white border border-black/[0.06] text-xs font-medium text-[#6b7280]"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process - Light with visual timeline */}
      <section className="py-40 bg-[#fafafa]">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="text-center mb-20">
            <h2 className="text-6xl font-bold text-[#0a0a0a] mb-6">
              Процесс{" "}
              <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                работы
              </span>
            </h2>
            <p className="text-xl text-[#6b7280] max-w-2xl mx-auto">
              Прозрачный процесс с чёткими этапами и регулярной
              синхронизацией.
            </p>
          </div>

          <div className="grid grid-cols-12 gap-6">
            <div className="col-span-2 col-start-2 relative">
              <div className="rounded-2xl bg-white border border-black/[0.06] p-6 shadow-sm hover:shadow-xl hover:scale-105 transition-all h-full">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center text-white font-bold mb-4">
                  1
                </div>
                <h3 className="text-lg font-bold text-[#0a0a0a] mb-2">
                  Погружение
                </h3>
                <p className="text-sm text-[#6b7280] leading-relaxed">
                  Изучаем рынок, пользователей, требования
                </p>
              </div>
              <div className="absolute top-1/2 -right-3 -translate-y-1/2 z-10">
                <div className="w-6 h-1 bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] rounded-full" />
              </div>
            </div>

            <div className="col-span-2 relative">
              <div className="rounded-2xl bg-white border border-black/[0.06] p-6 shadow-sm hover:shadow-xl hover:scale-105 transition-all h-full">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center text-white font-bold mb-4">
                  2
                </div>
                <h3 className="text-lg font-bold text-[#0a0a0a] mb-2">
                  Проектирование
                </h3>
                <p className="text-sm text-[#6b7280] leading-relaxed">
                  Архитектура, технологии, планирование
                </p>
              </div>
              <div className="absolute top-1/2 -right-3 -translate-y-1/2 z-10">
                <div className="w-6 h-1 bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] rounded-full" />
              </div>
            </div>

            <div className="col-span-2 relative">
              <div className="rounded-2xl bg-white border border-black/[0.06] p-6 shadow-sm hover:shadow-xl hover:scale-105 transition-all h-full">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center text-white font-bold mb-4">
                  3
                </div>
                <h3 className="text-lg font-bold text-[#0a0a0a] mb-2">
                  Дизайн
                </h3>
                <p className="text-sm text-[#6b7280] leading-relaxed">
                  Сценарии, структура, UI-дизайн
                </p>
              </div>
              <div className="absolute top-1/2 -right-3 -translate-y-1/2 z-10">
                <div className="w-6 h-1 bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] rounded-full" />
              </div>
            </div>

            <div className="col-span-2 relative">
              <div className="rounded-2xl bg-white border border-black/[0.06] p-6 shadow-sm hover:shadow-xl hover:scale-105 transition-all h-full">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center text-white font-bold mb-4">
                  4
                </div>
                <h3 className="text-lg font-bold text-[#0a0a0a] mb-2">
                  Разработка
                </h3>
                <p className="text-sm text-[#6b7280] leading-relaxed">
                  Итеративная разработка, тестирование
                </p>
              </div>
              <div className="absolute top-1/2 -right-3 -translate-y-1/2 z-10">
                <div className="w-6 h-1 bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] rounded-full" />
              </div>
            </div>

            <div className="col-span-2 relative">
              <div className="rounded-2xl bg-white border border-black/[0.06] p-6 shadow-sm hover:shadow-xl hover:scale-105 transition-all h-full">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center text-white font-bold mb-4">
                  5
                </div>
                <h3 className="text-lg font-bold text-[#0a0a0a] mb-2">
                  Запуск
                </h3>
                <p className="text-sm text-[#6b7280] leading-relaxed">
                  Развёртывание, мониторинг, поддержка
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Positioning - Light */}
      <section className="py-40 bg-white">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="grid grid-cols-12 gap-12">
            <div className="col-span-10 col-start-2">
              <div className="text-center mb-20">
                <h2 className="text-6xl font-bold text-[#0a0a0a] mb-6 leading-tight">
                  Мы работаем{" "}
                  <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                    не со всеми
                  </span>
                </h2>
                <p className="text-xl text-[#6b7280] max-w-3xl mx-auto leading-relaxed">
                  Мы фокусируемся на проектах, где ценятся
                  качество исполнения, продуманный подход и
                  прозрачная коммуникация.
                </p>
              </div>

              <div className="grid grid-cols-3 gap-8">
                {[
                  {
                    title: "Без хаотичных сроков",
                    desc: "Мы избегаем нереалистичных дедлайнов. Качество требует времени.",
                  },
                  {
                    title: "Не только про цену",
                    desc: "Если критерий — найти дшевле, мы не подходим.",
                  },
                  {
                    title: "Нужны понятные цели",
                    desc: "Проекты без чётких задач редко приводят к хорошему результату.",
                  },
                ].map((item, index) => (
                  <div key={index} className="group">
                    <div className="rounded-3xl bg-[#fafafa] border border-black/[0.06] p-10 h-full hover:bg-white hover:shadow-xl transition-all">
                      <div className="h-1 w-16 bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] rounded-full mb-6" />
                      <h3 className="text-2xl font-bold text-[#0a0a0a] mb-4">
                        {item.title}
                      </h3>
                      <p className="text-base text-[#6b7280] leading-relaxed">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section - Light with gradient accents */}
      <section className="py-40 bg-[#fafafa]">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="text-center mb-20">
            <h2 className="text-6xl font-bold text-[#0a0a0a] mb-6 leading-tight">
              Наши{" "}
              <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                проекты
              </span>
            </h2>
            <p className="text-xl text-[#6b7280] max-w-3xl mx-auto leading-relaxed">
              Примеры реализованных проектов, где мы применили наши подходы к дизайну и разработке.
            </p>
          </div>

          <div className="grid grid-cols-12 gap-8">
            {/* Project 1: ATB GROUP */}
            <div className="col-span-5 col-start-2 group">
              <div className="relative rounded-3xl bg-white border border-black/[0.06] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500">
                {/* Image Container */}
                <div className="relative h-[400px] overflow-hidden bg-gradient-to-br from-[#8b5cf6]/5 to-[#06b6d4]/5">
                  <ImageWithFallback 
                    src="https://images.unsplash.com/photo-1501755792080-cd51e405462c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW5keSUyMGNvbmZlY3Rpb25lcnklMjBmYWN0b3J5JTIwZGlzdHJpYnV0ионufGVufDF8fHx8MTc3MjE5ODIxNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="АТВ ГРУПП - дистрибьютор кондитерских изделий"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  {/* Gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                  
                  {/* Floating badge */}
                  <div className="absolute top-6 left-6">
                    <div className="inline-flex px-4 py-2 rounded-full bg-white/90 backdrop-blur-sm border border-white/20">
                      <span className="text-xs font-bold text-[#0a0a0a]">Веб-сайт</span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-8">
                  <h3 className="text-3xl font-bold text-[#0a0a0a] mb-3">
                    АТВ ГРУПП
                  </h3>
                  <p className="text-base text-[#6b7280] leading-relaxed mb-6">
                    Корпоративный сайт для дистрибьютора кондитерских изделий с каталогом продукции, информацией о компании и формами обратной связи.
                  </p>
                  
                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {["Next.js", "React", "Tailwind CSS", "CMS"].map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1.5 rounded-full bg-[#fafafa] border border-black/[0.06] text-xs font-medium text-[#6b7280]"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* CTA */}
                  <div className="flex items-center gap-2 text-sm font-bold bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent group-hover:gap-3 transition-all">
                    <span>Посмотреть проект</span>
                    <ExternalLink className="w-4 h-4 text-[#8b5cf6]" />
                  </div>
                </div>
              </div>
            </div>

            {/* Project 2: Beritravel */}
            <div className="col-span-5 group">
              <div className="relative rounded-3xl bg-white border border-black/[0.06] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500">
                {/* Image Container */}
                <div className="relative h-[400px] overflow-hidden bg-gradient-to-br from-[#06b6d4]/5 to-[#8b5cf6]/5">
                  <ImageWithFallback 
                    src="https://images.unsplash.com/photo-1571115929689-d6b638c10ef1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmbGlnaHQlMjBzZWFyY2glMjBtb2JpbGUlMjBhcHAlMjBpbnRlcmZhY2UlMjBibHVlfGVufDF8fHx8MTc3MjE5ODIxNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="Beritravel - поиск дешевых авиабилетов"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  {/* Gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                  
                  {/* Floating badge */}
                  <div className="absolute top-6 left-6">
                    <div className="inline-flex px-4 py-2 rounded-full bg-white/90 backdrop-blur-sm border border-white/20">
                      <span className="text-xs font-bold text-[#0a0a0a]">Сайт + Приложение</span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-8">
                  <h3 className="text-3xl font-bold text-[#0a0a0a] mb-3">
                    Beritravel
                  </h3>
                  <p className="text-base text-[#6b7280] leading-relaxed mb-6">
                    Платформа для поиска и бронирования недорогих авиабилетов с удобным интерфейсом, фильтрами и сравнением предложений от разных авиакомпаний.
                  </p>
                  
                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {["React", "TypeScript", "API Integration", "Mobile App"].map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1.5 rounded-full bg-[#fafafa] border border-black/[0.06] text-xs font-medium text-[#6b7280]"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* CTA */}
                  <div className="flex items-center gap-2 text-sm font-bold bg-gradient-to-r from-[#06b6d4] to-[#8b5cf6] bg-clip-text text-transparent group-hover:gap-3 transition-all">
                    <span>Посмотреть проект</span>
                    <ExternalLink className="w-4 h-4 text-[#06b6d4]" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA - Gradient section */}
      <section className="py-40 bg-gradient-to-br from-[#8b5cf6] via-[#a78bfa] to-[#06b6d4] text-white relative overflow-hidden">
        {/* Animated blobs */}
        <div className="absolute inset-0">
          <div className="absolute top-10 right-10 w-[500px] h-[500px] bg-white/10 rounded-full blur-3xl" />
          <div className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-white/10 rounded-full blur-3xl" />
        </div>

        <div className="mx-auto w-full max-w-[1440px] px-12 relative z-10">
          <div className="text-center space-y-10">
            <h2 className="text-7xl font-bold leading-tight">
              Обсудим ваш проект
            </h2>
            <p className="text-2xl text-white/90 max-w-2xl mx-auto leading-relaxed font-light">
              Расскажите о задаче, и мы честно оценим, подходим
              ли мы друг другу.
            </p>
            <div className="pt-6">
              <Link
                to="/contact"
                className="inline-flex items-center gap-3 rounded-2xl bg-white px-10 py-6 text-xl font-bold text-[#8b5cf6] shadow-2xl hover:scale-105 transition-all"
              >
                Связаться
                <ArrowRight className="h-6 w-6" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}