import { Link } from "react-router";
import { ArrowRight, Box, DollarSign, Package, Palette } from "lucide-react";

export function Services() {
  const mainServices = [
    {
      icon: Package,
      title: "Продуктовая стратегия",
      description: "Помогаем структурировать видение продукта, определить приоритеты и составить реалистичную дорожную карту.",
      features: [
        "Анализ требований и целей",
        "Определение scope и приоритетов",
        "Планирование этапов разработки",
        "Оценка рисков и сложности",
      ],
      color: "from-[#8b5cf6] to-[#a78bfa]",
    },
    {
      icon: Palette,
      title: "Продуктовый дизайн",
      description: "Проектируем интерфейсы с фокусом на логику взаимодействия, иерархию информации и удобство использования.",
      features: [
        "Проектирование UX-сценариев",
        "Разработка UI-интерфейсов",
        "Создание диайн-сстем",
        "Прототипирование и тестирование",
      ],
      color: "from-[#06b6d4] to-[#8b5cf6]",
    },
    {
      icon: Box,
      title: "Разработка продукта",
      description: "Создаём веб-приложения с использованием современного стека, стандартов кода и проверенных архитектурных паттернов.",
      features: [
        "Full-stack веб-приложения",
        "Проектирование API и интеграции",
        "Настройка инфраструктуры",
        "Тестирование и code review",
      ],
      color: "from-[#a78bfa] to-[#06b6d4]",
    },
    {
      icon: ArrowRight,
      title: "Техническая поддержка",
      description: "Помогаем с доработками, исправлениями, оптимизацией и развитием уже запущенных продуктов.",
      features: [
        "Рефакторинг и оптимизация",
        "Исправление ошибок",
        "Добавление новых функций",
        "Обновление зависимостей",
      ],
      color: "from-[#8b5cf6] to-[#06b6d4]",
    },
  ];

  return (
    <div className="bg-[#fafafa]">
      {/* Hero Section - Light with gradient */}
      <section className="pt-40 pb-24 bg-white relative overflow-hidden">
        <div className="absolute top-20 left-20 w-[500px] h-[500px] bg-gradient-to-br from-[#8b5cf6]/20 to-[#06b6d4]/20 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-[400px] h-[400px] bg-gradient-to-tl from-[#06b6d4]/15 to-[#a78bfa]/15 rounded-full blur-3xl" />
        
        <div className="mx-auto w-full max-w-[1440px] px-12 relative z-10">
          <div className="grid grid-cols-12 gap-12">
            <div className="col-span-8">
              <h1 className="text-7xl font-bold text-[#0a0a0a] leading-tight mb-8">
                <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                  Услуги
                </span>
              </h1>
              <p className="text-2xl text-[#6b7280] leading-relaxed font-light">
                От стратегии до разработки и поддержки — помогаем на разных этапах работы над цифровым продуктом.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Services - Light cards */}
      <section className="py-32 bg-[#fafafa]">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="space-y-8">
            {mainServices.map((service, index) => (
              <div
                key={index}
                className="group relative rounded-3xl bg-white border border-black/[0.06] shadow-sm hover:shadow-2xl transition-all overflow-hidden"
              >
                {/* Gradient glow on hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-0 group-hover:opacity-5 transition-opacity`} />
                
                <div className="grid grid-cols-12 gap-8 p-12 relative z-10">
                  {/* Left: Title & Description */}
                  <div className="col-span-4 space-y-6">
                    <div className={`inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br ${service.color} shadow-lg shadow-purple-500/25`}>
                      <service.icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-4xl font-bold text-[#0a0a0a]">{service.title}</h3>
                    <p className="text-lg text-[#6b7280] leading-relaxed">
                      {service.description}
                    </p>
                  </div>

                  {/* Right: Features */}
                  <div className="col-span-8 space-y-4">
                    {service.features.map((feature, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-4 rounded-2xl bg-[#fafafa] border border-black/[0.04] p-5 hover:bg-white transition-all"
                      >
                        <div className={`h-2 w-2 rounded-full bg-gradient-to-br ${service.color} flex-shrink-0`} />
                        <span className="text-base text-[#0a0a0a] font-medium">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tech Stack - Light background */}
      <section className="py-40 bg-white">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="grid grid-cols-12 gap-12 mb-24">
            <div className="col-span-5">
              <h2 className="text-6xl font-bold text-[#0a0a0a] leading-tight">
                <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                  Технологии
                </span>
              </h2>
            </div>
            <div className="col-span-6 col-start-7 flex items-center">
              <p className="text-xl text-[#6b7280] leading-relaxed">
                Используем проверенный современный стек, который подходит для большинства веб-приложений.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-12 gap-8">
            <div className="col-span-12 flex justify-center">
              <div className="grid grid-cols-3 gap-8 max-w-5xl">
                {[
                  { category: "Frontend", tools: ["React", "Next.js", "TypeScript", "Tailwind CSS"], gradient: "from-[#8b5cf6] to-[#a78bfa]" },
                  { category: "Backend", tools: ["Node.js", "Python", "GraphQL", "REST APIs"], gradient: "from-[#a78bfa] to-[#06b6d4]" },
                  { category: "База данных", tools: ["PostgreSQL", "MongoDB", "Redis", "Prisma"], gradient: "from-[#06b6d4] to-[#8b5cf6]" },
                ].map((stack, index) => (
                  <div key={index} className="group">
                    <div className="rounded-3xl bg-[#fafafa] border border-black/[0.06] p-8 h-full hover:bg-white hover:shadow-xl transition-all w-[250px]">
                      <div className={`inline-flex px-4 py-2 rounded-full bg-gradient-to-r ${stack.gradient} bg-opacity-10 mb-6`}>
                        <h4 className="text-xs font-bold text-[#0a0a0a] uppercase tracking-wider">{stack.category}</h4>
                      </div>
                      <ul className="space-y-3">
                        {stack.tools.map((tool) => (
                          <li key={tool} className="flex items-center gap-2">
                            <div className={`w-1.5 h-1.5 rounded-full bg-gradient-to-r ${stack.gradient}`} />
                            <span className="text-sm text-[#0a0a0a] font-medium">{tool}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Typical Timeline - Dark section for contrast */}
      <section className="py-40 bg-gradient-to-b from-[#0a0a0a] to-[#141414] text-white relative overflow-hidden">
        <div className="absolute top-0 right-1/4 w-[600px] h-[400px] bg-gradient-to-r from-[#8b5cf6]/30 to-[#06b6d4]/30 blur-3xl" />
        
        <div className="mx-auto w-full max-w-[1440px] px-12 relative z-10">
          <div className="grid grid-cols-12 gap-12 mb-24">
            <div className="col-span-5">
              <h2 className="text-6xl font-bold leading-tight text-white">
                Примерные<br />
                <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                  сроки
                </span>
              </h2>
            </div>
            <div className="col-span-6 col-start-7 flex items-center">
              <p className="text-xl text-[#a1a1aa] leading-relaxed">
                Каждый проект индивидуален, но вот ориентировочные временные рамки для разных типов работ.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-12 gap-8">
            <div className="col-span-12 flex justify-center">
              <div className="grid grid-cols-3 gap-8">
                {[
                  {
                    type: "Лендинг / сайт",
                    timeline: "2-4 недели",
                    description: "Продуктовый сайт с несколькими страницами, CMS, базовой аналитикой.",
                    gradient: "from-[#8b5cf6] to-[#a78bfa]",
                  },
                  {
                    type: "MVP приложения",
                    timeline: "6-12 недель",
                    description: "Функциональное веб-приложение с авторизацией, базовыми функциями, admin-панелью.",
                    gradient: "from-[#a78bfa] to-[#06b6d4]",
                  },
                  {
                    type: "Дизайн-система",
                    timeline: "4-8 недель",
                    description: "Полноценная дизайн-система с компонентами, документацией, примерами.",
                    gradient: "from-[#8b5cf6] to-[#06b6d4]",
                  },
                ].map((item, index) => (
                  <div key={index} className="group">
                    <div className="rounded-3xl bg-white/[0.05] border border-white/[0.1] p-8 h-full backdrop-blur-sm hover:bg-white/[0.08] transition-all">
                      <div className={`inline-flex px-3 py-1.5 rounded-full bg-gradient-to-r ${item.gradient} mb-6`}>
                        <div className="text-xs font-bold text-white uppercase tracking-wider">{item.type}</div>
                      </div>
                      <h3 className="text-3xl font-bold text-white mb-4">{item.timeline}</h3>
                      <p className="text-sm text-[#a1a1aa] leading-relaxed">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-12 gap-6 mt-8">
            <div className="col-span-12 rounded-2xl bg-white/[0.05] border border-white/[0.1] p-8 backdrop-blur-sm">
              <p className="text-base text-[#a1a1aa] leading-relaxed">
                <strong className="text-white font-semibold">Важно:</strong> Это ориентировочные оценки. Реальные сроки зависят от scope проекта, сложности требований, готовности контента и скорости обратной связи от вашей команды.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA - Gradient */}
      <section className="py-40 bg-gradient-to-br from-[#8b5cf6] via-[#a78bfa] to-[#06b6d4] relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-10 right-10 w-[500px] h-[500px] bg-white/10 rounded-full blur-3xl" />
          <div className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-white/10 rounded-full blur-3xl" />
        </div>

        <div className="mx-auto w-full max-w-[1440px] px-12 relative z-10">
          <div className="text-center space-y-10">
            <h2 className="text-7xl font-bold text-white leading-tight">
              Обсудим ваш проект
            </h2>
            <p className="text-2xl text-white/90 max-w-2xl mx-auto leading-relaxed font-light">
              Расскажите о задаче, и мы подготовим честную оценку сроков и стоимости.
            </p>
            <div className="pt-6">
              <Link
                to="/contact"
                className="inline-flex items-center gap-3 rounded-2xl bg-white px-10 py-6 text-xl font-bold text-[#8b5cf6] shadow-2xl hover:scale-105 transition-all"
              >
                Связаться
                <ArrowRight className="h-6 w-6" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}