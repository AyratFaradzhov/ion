import { Heart, Shield, TrendingUp, Users } from "lucide-react";

export function About() {
  const values = [
    {
      icon: TrendingUp,
      title: "Качество над скоростью",
      description: "Лучше потратить больше времени и сделать правильно, чем торопиться и переделывать.",
      gradient: "from-[#8b5cf6] to-[#a78bfa]",
    },
    {
      icon: Shield,
      title: "Честность",
      description: "Говорим прямо о рисках, сложности и реалистичных сроках. Без приукрашивания.",
      gradient: "from-[#a78bfa] to-[#06b6d4]",
    },
    {
      icon: Users,
      title: "Прозрачность",
      description: "Вы всегда понимаете, что происходит, на каком этапе проект и сколько времени осталось.",
      gradient: "from-[#06b6d4] to-[#8b5cf6]",
    },
    {
      icon: Heart,
      title: "Постоянное развитие",
      description: "Учимся на каждом проекте, следим за технологиями, улучшаем процессы.",
      gradient: "from-[#8b5cf6] to-[#06b6d4]",
    },
  ];

  return (
    <div className="bg-[#fafafa]">
      {/* Hero Section - Light with gradient */}
      <section className="pt-40 pb-24 bg-white relative overflow-hidden">
        <div className="absolute top-20 right-20 w-[500px] h-[500px] bg-gradient-to-br from-[#8b5cf6]/20 to-[#06b6d4]/20 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-gradient-to-tl from-[#06b6d4]/15 to-[#a78bfa]/15 rounded-full blur-3xl" />
        
        <div className="mx-auto w-full max-w-[1440px] px-12 relative z-10">
          <div className="grid grid-cols-12 gap-12">
            <div className="col-span-8">
              <h1 className="text-7xl font-bold text-[#0a0a0a] leading-tight mb-8">
                <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">О команде</span>
              </h1>
              <p className="text-2xl text-[#6b7280] leading-relaxed font-light">
                Мы — небольшая команда разработчиков и дизайнеров, которая фокусируется на качественном исполнении и продуманном подходе к созданию цифровых продуктов.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Story - Light background */}
      <section className="py-40 bg-[#fafafa]">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="grid grid-cols-12 gap-12">
            <div className="col-span-4">
              <h2 className="text-6xl font-bold text-[#0a0a0a] leading-tight">
                Как мы<br />
                <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                  работаем
                </span>
              </h2>
            </div>
            <div className="col-span-7 col-start-6 space-y-8">
              <div className="rounded-3xl bg-white border border-black/[0.06] p-10 shadow-sm">
                <p className="text-xl text-[#0a0a0a] leading-relaxed mb-6">
                  Prism — это команда людей, которые любят создавать продуманные, качественно реализованные веб-приложения. Мы не огромное агентство с десятками проектов одновременно, и это наше осознанное решение.
                </p>
                <p className="text-lg text-[#6b7280] leading-relaxed">
                  Мы работаем над небольшим количеством проектов, чтобы каждому уделить достаточно внимания.
                </p>
              </div>
              
              <div className="rounded-3xl bg-white border border-black/[0.06] p-10 shadow-sm">
                <p className="text-xl text-[#0a0a0a] leading-relaxed mb-6">
                  Это позволяет нам действительно погружаться в задачу, разбираться в деталях и делать не просто «работающее», а хорошо спроектированное решение.
                </p>
                <p className="text-lg text-[#6b7280] leading-relaxed">
                  Мы честно говорим о том, что можем и не можем сделать, реалистично оцениваем сроки и держим обещания.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values - Light cards */}
      <section className="py-40 bg-white">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="grid grid-cols-12 gap-12 mb-24">
            <div className="col-span-4">
              <h2 className="text-6xl font-bold text-[#0a0a0a] leading-tight">
                Наши<br />
                <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                  принципы
                </span>
              </h2>
            </div>
            <div className="col-span-6 col-start-7 flex items-center">
              <p className="text-xl text-[#6b7280] leading-relaxed">
                Ценности, которыми мы руководствуемся в работе.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-12 gap-8">
            {values.map((value, index) => (
              <div
                key={index}
                className="col-span-6 group"
              >
                <div className="rounded-3xl bg-[#fafafa] border border-black/[0.06] p-12 h-full hover:bg-white hover:shadow-xl transition-all">
                  <div className={`inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br ${value.gradient} shadow-lg shadow-purple-500/25 mb-8`}>
                    <value.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-[#0a0a0a] mb-4">{value.title}</h3>
                  <p className="text-lg text-[#6b7280] leading-relaxed">{value.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Size - Dark section for contrast */}
      <section className="py-40 bg-gradient-to-b from-[#0a0a0a] to-[#141414] text-white relative overflow-hidden">
        <div className="absolute top-0 left-1/4 w-[600px] h-[400px] bg-gradient-to-r from-[#8b5cf6]/30 to-[#06b6d4]/30 blur-3xl" />
        
        <div className="mx-auto w-full max-w-[1440px] px-12 relative z-10">
          <div className="grid grid-cols-12 gap-12">
            <div className="col-span-10 col-start-2">
              <div className="rounded-3xl bg-white/[0.05] border border-white/[0.1] p-16 backdrop-blur-sm">
                <div className="grid grid-cols-3 gap-16">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-white mb-4">Небольшая</div>
                    <div className="text-sm text-[#a1a1aa] font-semibold uppercase tracking-wider mb-6">Размер команды</div>
                    <p className="text-sm text-[#a1a1aa] leading-relaxed">
                      Мы сознательно остаёмся компактной командой
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-white mb-4">Разные</div>
                    <div className="text-sm text-[#a1a1aa] font-semibold uppercase tracking-wider mb-6">Специализации</div>
                    <p className="text-sm text-[#a1a1aa] leading-relaxed">
                      Дизайнеры, фронтенд, бэкенд, DevOps
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-white mb-4">Remote</div>
                    <div className="text-sm text-[#a1a1aa] font-semibold uppercase tracking-wider mb-6">Формат работы</div>
                    <p className="text-sm text-[#a1a1aa] leading-relaxed">
                      Работаем удалённо, но координируемся синхронно
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* What We're Not - Light background */}
      <section className="py-40 bg-[#fafafa]">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="grid grid-cols-12 gap-12">
            <div className="col-span-4">
              <h2 className="text-6xl font-bold text-[#0a0a0a] leading-tight">
                Чем мы<br />
                <span className="bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] bg-clip-text text-transparent">
                  не являемся
                </span>
              </h2>
            </div>
            <div className="col-span-7 col-start-6 space-y-8">
              <div className="rounded-3xl bg-white border border-black/[0.06] p-10 shadow-sm hover:shadow-xl transition-all">
                <h3 className="text-2xl font-bold text-[#0a0a0a] mb-4">Мы не агентство с десятками проектов</h3>
                <p className="text-lg text-[#6b7280] leading-relaxed">
                  Мы работаем только над несколькими проектами одновременно, чтобы каждому уделить достаточно внимания.
                </p>
              </div>
              
              <div className="rounded-3xl bg-white border border-black/[0.06] p-10 shadow-sm hover:shadow-xl transition-all">
                <h3 className="text-2xl font-bold text-[#0a0a0a] mb-4">Мы не обещаем быстрых результатов</h3>
                <p className="text-lg text-[#6b7280] leading-relaxed">
                  Качественная разработка требует времени на проектирование, реализацию и тестирование. Мы не идём на компромиссы ради скорости.
                </p>
              </div>
              
              <div className="rounded-3xl bg-white border border-black/[0.06] p-10 shadow-sm hover:shadow-xl transition-all">
                <h3 className="text-2xl font-bold text-[#0a0a0a] mb-4">Мы не самый дешёвый вариант</h3>
                <p className="text-lg text-[#6b7280] leading-relaxed">
                  Если критерий выбора — минимальная цена, мы, скорее всего, не подходим. Наша ценность — в подходе и качестве исполнения.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA - Gradient */}
      <section className="py-40 bg-gradient-to-br from-[#8b5cf6] via-[#a78bfa] to-[#06b6d4] relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-10 right-10 w-[500px] h-[500px] bg-white/10 rounded-full blur-3xl" />
          <div className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-white/10 rounded-full blur-3xl" />
        </div>

        <div className="mx-auto w-full max-w-[1440px] px-12 relative z-10">
          <div className="text-center space-y-10">
            <h2 className="text-7xl font-bold text-white leading-tight">
              Подходим ли мы друг другу?
            </h2>
            <p className="text-2xl text-white/90 max-w-2xl mx-auto leading-relaxed font-light">
              Расскажите о вашей задаче, и мы честно оценим, сможем ли мы помочь.
            </p>
            <div className="pt-6">
              <a
                href="/contact"
                className="inline-flex items-center gap-3 rounded-2xl bg-white px-10 py-6 text-xl font-bold text-[#8b5cf6] shadow-2xl hover:scale-105 transition-all"
              >
                Связаться
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}