import { Link, Outlet, useLocation } from "react-router";
import { ArrowRight } from "lucide-react";

export function Layout() {
  const location = useLocation();

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* Navigation - Light with blur */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-black/[0.06] bg-white/80 backdrop-blur-xl">
        <div className="mx-auto w-full max-w-[1440px] px-12">
          <div className="grid grid-cols-12 gap-6 items-center h-20">
            {/* Logo - Spans 2 columns */}
            <div className="col-span-2">
              <Link to="/" className="inline-flex items-center gap-3 group">
                <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center shadow-lg shadow-purple-500/20">
                  <span className="text-sm font-bold text-white">P</span>
                </div>
                <span className="text-base font-bold text-[#0a0a0a] tracking-tight">Prism</span>
              </Link>
            </div>

            {/* Navigation Links - Centered, spans 8 columns */}
            <div className="col-span-8 flex items-center justify-center gap-8">
              <Link
                to="/"
                className={`text-sm font-medium transition-colors ${
                  isActive("/")
                    ? "text-[#0a0a0a]"
                    : "text-[#6b7280] hover:text-[#0a0a0a]"
                }`}
              >
                Главная
              </Link>
              <Link
                to="/work"
                className={`text-sm font-medium transition-colors ${
                  isActive("/work")
                    ? "text-[#0a0a0a]"
                    : "text-[#6b7280] hover:text-[#0a0a0a]"
                }`}
              >
                Подход
              </Link>
              <Link
                to="/services"
                className={`text-sm font-medium transition-colors ${
                  isActive("/services")
                    ? "text-[#0a0a0a]"
                    : "text-[#6b7280] hover:text-[#0a0a0a]"
                }`}
              >
                Услуги
              </Link>
              <Link
                to="/about"
                className={`text-sm font-medium transition-colors ${
                  isActive("/about")
                    ? "text-[#0a0a0a]"
                    : "text-[#6b7280] hover:text-[#0a0a0a]"
                }`}
              >
                О команде
              </Link>
            </div>

            {/* CTA - Spans 2 columns, aligned right */}
            <div className="col-span-2 flex justify-end">
              <Link
                to="/contact"
                className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[#8b5cf6] to-[#06b6d4] px-6 py-2.5 text-sm font-semibold text-white shadow-lg shadow-purple-500/25 transition-all hover:shadow-xl hover:shadow-purple-500/30 hover:scale-105"
              >
                Связаться
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-20">
        <Outlet />
      </main>

      {/* Footer - Dark section for contrast */}
      <footer className="border-t border-black/[0.06] bg-gradient-to-b from-[#0a0a0a] to-[#141414] text-white">
        <div className="mx-auto w-full max-w-[1440px] px-12 py-24">
          <div className="grid grid-cols-12 gap-6 mb-24">
            {/* Brand - Spans 5 columns */}
            <div className="col-span-5">
              <Link to="/" className="inline-flex items-center gap-3 group mb-6">
                <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-[#8b5cf6] to-[#06b6d4] flex items-center justify-center shadow-lg shadow-purple-500/30">
                  <span className="text-sm font-bold text-white">P</span>
                </div>
                <span className="text-base font-bold text-white tracking-tight">Prism</span>
              </Link>
              <p className="text-sm text-[#a1a1aa] leading-relaxed max-w-md">
                Команда для продуманной разработки цифровых продуктов.
              </p>
            </div>

            {/* Navigation - Spans 2 columns */}
            <div className="col-span-2 col-start-7">
              <h4 className="text-sm font-semibold text-white mb-6">Навигация</h4>
              <ul className="space-y-4">
                <li>
                  <Link to="/work" className="text-sm text-[#a1a1aa] hover:text-white transition-colors">
                    Подход
                  </Link>
                </li>
                <li>
                  <Link to="/services" className="text-sm text-[#a1a1aa] hover:text-white transition-colors">
                    Услуги
                  </Link>
                </li>
                <li>
                  <Link to="/about" className="text-sm text-[#a1a1aa] hover:text-white transition-colors">
                    О команде
                  </Link>
                </li>
                <li>
                  <Link to="/contact" className="text-sm text-[#a1a1aa] hover:text-white transition-colors">
                    Контакты
                  </Link>
                </li>
              </ul>
            </div>

            {/* Social - Spans 2 columns */}
            <div className="col-span-2">
              <h4 className="text-sm font-semibold text-white mb-6">Соцсети</h4>
              <ul className="space-y-4">
                <li>
                  <a href="#" className="text-sm text-[#a1a1aa] hover:text-white transition-colors">
                    Twitter
                  </a>
                </li>
                <li>
                  <a href="#" className="text-sm text-[#a1a1aa] hover:text-white transition-colors">
                    LinkedIn
                  </a>
                </li>
                <li>
                  <a href="#" className="text-sm text-[#a1a1aa] hover:text-white transition-colors">
                    GitHub
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="pt-8 border-t border-white/[0.1] grid grid-cols-12 gap-6 items-center">
            <div className="col-span-6">
              <p className="text-sm text-[#71717a]">
                © 2026 Prism
              </p>
            </div>
            <div className="col-span-6 flex justify-end gap-8">
              <a href="#" className="text-sm text-[#71717a] hover:text-[#a1a1aa] transition-colors">
                Конфиденциальность
              </a>
              <a href="#" className="text-sm text-[#71717a] hover:text-[#a1a1aa] transition-colors">
                Условия
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
